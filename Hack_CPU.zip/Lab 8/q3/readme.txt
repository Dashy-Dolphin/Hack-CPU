RUN IN CPU EMULATOR

q3a.asm contains the machine code for 
        d = a + b - c;
q3a.tst has script with two testcases for CPU Emulator

q3b.asm contains the machine code  for
      if (a > b) then c = a - b else c = b - a
q3b.tst has script with two testcases for CPU Emulator

q3c.asm contains the machine code for 

int i = 1
int sum = 0
while (i < 100)
 { 
 sum = sum + i;

 i = i + 1;

 }

 q3c.tst has script for CPU Emulator

 Each of the three bits also has a cmp file